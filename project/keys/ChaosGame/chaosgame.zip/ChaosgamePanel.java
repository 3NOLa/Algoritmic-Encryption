import java.awt.*;
import javax.swing.*;

public class ChaosgamePanel extends JPanel{

    private Shape shape;
    private final int WIDTH = 800;
    private final int HEIGHT = 800;
    
    public ChaosgamePanel()
    {
        setPreferredSize(new Dimension(WIDTH,HEIGHT));
        shape = new Shape(3,WIDTH, HEIGHT);
        shape.printVertices();
    }

    public static void displayChaosGame() {
        JFrame frame = new JFrame("Chaos Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new ChaosgamePanel());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
}

class main3{
    public static void main(String[] args) {
        ChaosgamePanel.displayChaosGame();
    }
}
