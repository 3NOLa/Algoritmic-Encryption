import java.awt.Point;
import java.awt.geom.*;

public class Shape {
    
    private int verticesAmount;
    public Point2D[] vertices;
    private final int WIDTH;
    private final int HEIGHT;

    public Shape(int verticesAmount, int WIDTH, int HEIGHT)
    {
        this.HEIGHT = HEIGHT;
        this.WIDTH = WIDTH;
        this.verticesAmount = verticesAmount;
        this.vertices = new Point2D[this.verticesAmount];

        calculatePositions();
    }

    private void calculatePositions()
    {
        int cx = this.WIDTH / 2;
        int cy = this.HEIGHT / 2;
        int radius = this.HEIGHT / 4;
        int degree = 360 / this.verticesAmount;

        for(int i=0;i<verticesAmount;i++)
        {
            int xi = cx + (int) (radius * Math.cos(degree * i));
            int yi = cy + (int) (radius * Math.sin(degree * i));

            this.vertices[i] = new Point(xi, yi);
        }
        
    }

    public void printVertices()
    {
        for (int i = 0; i < vertices.length; i++) {
            System.out.println("x " + vertices[i].getX() + "y " + vertices[i].getY());
        }
    }

}
